<html>
    <head>
        <style>
            /** 
                Set the margins of the page to 0, so the footer and the header
                can be of the full height and width !
             **/
            @page  {
                margin: 0cm 0cm;
                
            }

            /** Define now the real margins of every page in the PDF **/
            body {
                
           
                margin-top: 4cm;
                margin-left: 1.5cm;
                margin-right: 1cm;
                margin-bottom: 2cm;
            }

            /** Define the header rules **/
            header {
                position: fixed;
                top: 1cm;
                left: 1cm;
                right: 0cm;
                height: 3cm;
                
                display: block;
                margin-right: auto;
                width: 25%;
            }

            /** Define the footer rules **/
            footer {
                position: fixed; 
                bottom: 0cm; 
                left: 0cm; 
                right: 0cm;
                height: 2cm;
            }


            .tabla  {
                border-collapse:collapse;
                border-spacing:0;
                text-align: justify;
                font-size: 12px;
            }
            .celdaNegrita {
                background:#F5B041;

                border-top-style: solid;
                border-top-width: 3px;

                
                border-left-style: double;
                border-left-width: 4px;

                border-right-style: solid;
                border-right-width: 3px;
                padding:10px 5px;
            }
            .celdaBlancaInicio {
                background:#0F15A9;
                padding:5px 5px;

                border-top-style: solid;
                border-top-color: white;

                border-left-style: double;
                border-left-color: black;
                border-left-width: 4px;

                border-right-style: solid;
                border-right-color: white;

                border-bottom-style: solid;
                border-bottom-color: white; 
                padding:5px 5px;
                
            }
            .celdaBlancaCentro {
                background:#0F15A9;

                border-top-style: solid;
                border-top-color: white;

                border-left-style: solid;
                border-left-color: white;

                border-right-style: solid;
                border-right-color: white;

                border-bottom-style: solid;
                border-bottom-color: white; 
                padding:5px 5px;
                
            }
            .celdaBlancaFinal {
                background:#0F15A9;
                padding:5px 5px;

                border-top-style: solid;
                border-top-color: white;

                border-left-style: solid;
                border-left-color: white;

                border-right-style: solid;
                border-right-color: black;
                border-right-width: 4px; 

                border-bottom-style: solid;
                border-bottom-color: white;
            }
            .celdaPunteadoInicial {
                border-left-style:double;
                border-left-color: black;
                border-left-width: 4px;

                border-right-style:dashed;
                border-bottom-style:dashed;
                border-top-style:dashed;
                padding:3px 3px;

                color:#273746;
            }
            .celdaPunteadoCentral{
                border-left-style:dashed;
                border-right-style:dashed;
                border-bottom-style:dashed;
                border-top-style:dashed;
                padding:3px 3px;

                color:#273746;
            }
            .celdaPunteadoFinal{
                border-left-style:dashed;

                border-right-style:solid;
                border-right-color: black;
                border-right-width: 4px;

                border-bottom-style:dashed;
                border-top-style:dashed;
                padding:3px 3px;

                color:#273746;
            }
            .celdaObservaciones{
                border-top-style:double;
                border-top-width: 4px;
                padding:3px 3px;
            }
            .costoDirecto{
                
                border-top-style:double;
                border-top-width: 4px;
                padding:3px 3px;
                
            }
            .tabla2  {
                
                border-collapse:collapse;
                border-spacing:0;
                text-align: justify;
                font-size: 12px;
            }
            
        </style>
    </head>
    <body>
        <!-- Define header and footer blocks before your content -->
        
        <header>
            <img src="https://www.rayroasociadossac.com/wp-content/uploads/2017/01/LOGO.png" width="250" height="70"/>
        </header>

        <footer>
            <img src="footer.png" width="100%" height="100%"/>
        </footer>

        <!-- Wrap the content of your PDF inside a main tag -->
        <main>
            <table width="100%">
            <?php
                $monthNum  = date('m', strtotime(@$data_asignacion->created_at));
                $year  = date('Y', strtotime(@$data_asignacion->created_at));
                $day  = date('w', strtotime(@$data_asignacion->created_at));
                
                $diassemana = array("Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sábado");
                
                $dayEspañol='';
                

                $monthNameSpanish='';
                switch($monthNum)
                {   
                    case "01":
                    $monthNameSpanish = "Enero";
                    break;

                    case "02":
                    $monthNameSpanish = "Febrero";
                    break;

                    case "03":
                    $monthNameSpanish = "Marzo";
                    break;
                  
                    case "04":
                    $monthNameSpanish = "Abril";
                    break;
                    case "05":
                    $monthNameSpanish = "Mayo";
                    break;
                    case "06":
                    $monthNameSpanish = "Junio";
                    break;
                    case "07":
                    $monthNameSpanish = "Julio";
                    break;
                    case "08":
                    $monthNameSpanish = "Agosto";
                    break;
                    case "09":
                    $monthNameSpanish = "Setiembre";
                    break;
                    case "10":
                    $monthNameSpanish = "Octubre";
                    break;
                    case "11":
                    $monthNameSpanish = "Noviembre";
                    break;
                    case "12":
                    $monthNameSpanish = "Diciembre";
                    break;
                    //...
                }
                
                ?>
                <tr>
                    <td width="100%" align="right"><strong style="font-size: 12px;"> <?php echo e(@$diassemana[$day]); ?>, 17 de <?php echo e(@$monthNameSpanish); ?> de <?php echo e(@$year); ?></strong></td>
                </tr>
            </table>
            <table width="100%">
                <tr>
                    <td width="12%" align="left"><strong style="font-size: 12px;color:#2874A6">PROYECTO</strong></td>
                    <td width="88%" align="left"><strong style="font-size: 12px;">:&nbsp;&nbsp;<?php echo e(@$data_asignacion->codigoTicket); ?></strong></td>
                </tr>
                
                <tr>
                    <td width="12%" align="left"><strong style="font-size: 12px;color:#2874A6">SEDE</strong></td>
                    <td width="88%" align="left"><strong style="font-size: 12px;">:&nbsp;&nbsp;<?php echo e(@$local->DistNom); ?></strong></td>
                </tr>
                <tr>
                    <td width="12%" align="left"><strong style="font-size: 12px;color:#2874A6">CLIENTE</strong></td>
                    <td width="88%" align="left"><strong style="font-size: 12px;">:&nbsp;&nbsp;<?php print_r(env('CLIENTE'));?></strong></td>
                </tr>
                <tr>
                    <td width="12%" align="left"><strong style="font-size: 12px;color:#2874A6">R.U.C.</strong></td>
                    <td width="88%" align="left"><strong style="font-size: 12px;">:&nbsp;&nbsp;<?php print_r(env('RUC1'));?></strong></td>
                </tr>
                <tr>
                    <td width="12%" align="left"><strong style="font-size: 12px;color:#2874A6">DIRECCION</strong></td>
                    <td width="88%" align="left"><strong style="font-size: 12px;">:&nbsp;&nbsp;:<?php echo e(@$data_asignacion->direccionLocal); ?></strong></td>
                </tr>
                <tr>
                    <td width="12%" align="left"><strong style="font-size: 12px;color:#2874A6">ATENCION</strong></td>
                    <td width="88%" align="left"><strong style="font-size: 12px;">:&nbsp;&nbsp;<?php echo e(@$data_asignacion->atencion); ?></strong></td>
                </tr>
                
            </table>
            
            <table width="100%">
            <?php for($i = 1; $i <=6; $i++): ?>
                <tr>
                    <td width="100%" align="center"><strong style="font-size: 12px;color:white"></strong></td>
                </tr>
            <?php endfor; ?>
            </table>
            
            <table width="100%">
                <tr>
                    <td width="100%" align="center"><strong style="font-size: 12px;">PRESUPUESTO RA&RO N° <?php echo e(@$data_asignacion->asignacionId); ?></strong></td>
                </tr>
            </table>
            <table width="100%">
                <tr>
                    <td width="100%" align="left" style="font-size: 12px;">Por medio de la presente ponemos a vuestra consideración nuestra mejor oferta económica por los siguientes servicios de trabajo a realizar:</td>
                </tr>
            </table>

            <table width="100%">
            <?php for($i = 1; $i <=4; $i++): ?>
                <tr>
                    <td width="100%" align="center"><strong style="font-size: 12px;color:white"></strong></td>
                </tr>
            <?php endfor; ?>
            </table>
        
            <table class="tabla" width="100%" >
                <thead>
                <tr>
                    <th width="100%" align="center" colspan="6" class="celdaNegrita">QIMI PV Miraflores#T0178481</th>
                </tr>
                </thead>

                <tbody>
                    <tr>
                        <td width="3%" align="center" class="celdaBlancaInicio"><strong style="color:white">PARTIDA</strong></td>
                        <td width="85%" align="center" class="celdaBlancaCentro"><strong style="color:white">Descripcion</strong></td>
                        <td width="3%" align="center" class="celdaBlancaCentro"><strong style="color:white">U.M</strong></td>
                        <td width="3%" align="center" class="celdaBlancaCentro"><strong style="color:white">Metrado</strong></td>
                        <td width="3%" align="center" class="celdaBlancaCentro"><strong style="color:white">PU</strong></td>
                        <td width="3%" align="center" class="celdaBlancaFinal"><strong style="color:white">P.Parcial</strong></td>
                    </tr>
                    <?php $total=0; ?>
                    <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td align="center" class="celdaPunteadoInicial"><?php echo e(@$tarea->SubCategoria->codigo); ?></td>
                        <td align="left" class="celdaPunteadoCentral"><?php echo e(@$tarea->SubCategoria->descripcion); ?></td>
                        <td align="center" class="celdaPunteadoCentral"><?php echo e(@$tarea->unidadMedida); ?></td>
                        <td align="center" class="celdaPunteadoCentral"><?php echo e(@$tarea->cantidad); ?></td>
                        <td align="right" class="celdaPunteadoCentral"><?php echo e(@sprintf("%.2f",@$tarea->precioAdministrador)); ?></td>
                        <td align="right" class="celdaPunteadoFinal"><?php echo e(@sprintf("%.2f",@$tarea->precioAdministrador * @$tarea->cantidad)); ?></td>
                        <?php $total+=@$tarea->precioAdministrador * @$tarea->cantidad;?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr>
                        <td  colspan="2" class="celdaObservaciones"></td>
                        <td align="left"colspan="3" class="costoDirecto"></td>
                        <td align="right" class="costoDirecto"></td>
                    </tr>
                    <tr>
                        <td  colspan="2" ><strong style="color:red"> OBSERVACIÓN </strong></td>
                        <td align="left"colspan="3" style="background:#4349D1"><strong style="color:white"> COSTO DIRECTO</strong></td>
                        <td align="right" style="background:#4349D1" ><strong style="color:white">S/.<?php echo e(@sprintf("%.2f",$total)); ?></strong></td>
                    </tr>
                    <tr>
                        <td  colspan="2"  ><?php echo e(@$data_asignacion->observaciones); ?></td>
                        <td align="left"colspan="3"></td>
                        <td align="right" ></td>
                    </tr>
                </tbody>
            </table>

            <table width="100%">
            <?php for($i = 1; $i <=4; $i++): ?>
                <tr>
                    <td width="100%" align="center"><strong style="font-size: 12px;color:white"></strong></td>
                </tr>
            <?php endfor; ?>
            </table>

            <table class="tabla2" width="100%">
                <tr>
                    <td width="1%" align="right"></td>
                    <td width="10%" align="center"><strong>I</strong></td>
                    <td width="89%" ><strong>CONDICIONES</strong></td>
                </tr>
                <tr>
                    <td width="1%" align="right"></td>
                    <td width="10%" align="center"><strong></strong></td>
                    <td width="89%" ><strong></strong></td>
                </tr>
                <tr>
                    <td width="1%" align="right"></td>
                    <td width="10%" align="center"><strong></strong></td>
                    <td width="89%" >* <?php print_r(env('CONDICIONES')); ?></td>
                </tr>
            </table>

            <table width="100%">
            <?php for($i = 1; $i <=4; $i++): ?>
                <tr>
                    <td width="100%" align="center"><strong style="font-size: 12px;color:white"></strong></td>
                </tr>
            <?php endfor; ?>
            </table>

            <table class="tabla2" width="100%">
                <tr>
                    <td width="1%" align="right"></td>
                    <td width="10%" align="center"><strong>II</strong></td>
                    <td width="89%" ><strong>INCLUYE</strong></td>
                </tr>
                <tr>
                    <td width="1%" align="right"></td>
                    <td width="10%" align="center"><strong></strong></td>
                    <td width="89%" ><strong></strong></td>
                </tr>
                <tr>
                    <td width="1%" align="right"></td>
                    <td width="10%" align="center"><strong></strong></td>
                    <td width="89%" >* <?php print_r(env('INCLUYE1')); ?></td>
                </tr>
                <tr>
                    <td width="1%" align="right"></td>
                    <td width="10%" align="center"><strong></strong></td>
                    <td width="89%" >* <?php print_r(env('INCLUYE2')); ?></td>
                </tr>
                <tr>
                    <td width="1%" align="right"></td>
                    <td width="10%" align="center"><strong></strong></td>
                    <td width="89%" >* <?php print_r(env('INCLUYE3')); ?></td>
                </tr>
                <tr>
                    <td width="1%" align="right"></td>
                    <td width="10%" align="center"><strong></strong></td>
                    <td width="89%" >* <?php print_r(env('INCLUYE4')); ?></td>
                </tr>
                <tr>
                    <td width="1%" align="right"></td>
                    <td width="10%" align="center"><strong></strong></td>
                    <td width="89%" >* <?php print_r(env('INCLUYE5')); ?></td>
                </tr>
                <tr>
                    <td width="1%" align="right"></td>
                    <td width="10%" align="center"><strong></strong></td>
                    <td width="89%" >* <?php print_r(env('INCLUYE6')); ?></td>
                </tr>
                <tr>
                    <td width="1%" align="right"></td>
                    <td width="10%" align="center"><strong></strong></td>
                    <td width="89%" >* <?php print_r(env('INCLUYE7')); ?></td>
                </tr>
                <tr>
                    <td width="1%" align="right"></td>
                    <td width="10%" align="center"><strong></strong></td>
                    <td width="89%" >* <?php print_r(env('INCLUYE8')); ?></td>
                </tr>
                
            </table>

            <table width="100%">
            <?php for($i = 1; $i <=4; $i++): ?>
                <tr>
                    <td width="100%" align="center"><strong style="font-size: 12px;color:white"></strong></td>
                </tr>
            <?php endfor; ?>
            </table>
            
            <table class="tabla2" width="100%">
                <tr>
                    <td width="1%" align="right"></td>
                    <td width="10%" align="center"><strong>III</strong></td>
                    <td width="89%"  colspan="2"><strong>TOMAS FOTOGRÁFICAS ACTUAL</strong></td>
                </tr>
                <?php for($i = 0 ; $i <  count(@$data_asignacion->fotosInicio) ; $i++): ?>
              
                <tr>
                    <td width="1%"></td>
                    <td width="10%"></td>
                    <td width="44.5%"><img src=<?php print_r(@$data_asignacion->fotosInicio[$i]->url); ?> width="300" height="150"/></td>
                    <?php if(isset($data_asignacion->fotosInicio[$i+1]->url)==true): ?>
                        
                        <td width="44.5%"><img src=<?php print_r(@$data_asignacion->fotosInicio[$i+1]->url); ?> width="300" height="150"/></td>
                        <?php $i+=1 ?>
                    <?php else: ?>
                        <td width="44.5%"></td>
                    <?php endif; ?>
                   
                </tr>
                
                <?php endfor; ?>
                
            </table>

            <table width="100%">
            <?php for($i = 1; $i <=4; $i++): ?>
                <tr>
                    <td width="100%" align="center"><strong style="font-size: 12px;color:white"></strong></td>
                </tr>
            <?php endfor; ?>
            </table>

            <table class="tabla2" width="100%">
                <tr>
                    <td width="1%" align="right"></td>
                    <td width="10%" align="center"><strong>IV</strong></td>
                    <td width="89%" colspan="2" ><strong>DATOS ADICIONALES</strong></td>
                </tr>
            </table>

            <table class="tabla2" width="100%">
                <tr>
                    <td width="1%"></td>
                    <td width="10%"></td>
                    <td width="25%" ><strong>RAZON SOCIAL</strong></td>
                    <td width="64%" >: <?php print_r(env('RAZON_SOCIAL'));?></td>
                </tr>
                <tr>
                    <td width="1%"></td>
                    <td width="10%"></td>
                    <td width="25%" ><strong>RUC</strong></td>
                    <td width="64%" >: <?php print_r(env('RUC2'));?></td>
                </tr>
                <tr>
                    <td width="1%"></td>
                    <td width="10%"></td>
                    <td width="25%" ><strong>TIEMPO DE GARANTÍA </strong></td>
                    <td width="64%" >:  <?php print_r(env('TIEMPO_GARANTIA'));?></td>
                </tr>
                <tr>
                    <td width="1%"></td>
                    <td width="10%"></td>
                    <td width="25%" ><strong>FORMA DE PAGO</strong></td>
                    <td width="64%" >: <?php print_r(env('FORMA_PAGO'));?></td>
                </tr>
                <tr>
                    <td width="1%"></td>
                    <td width="10%"></td>
                    <td width="25%" ><strong>DISPONIBILIDAD</strong></td>
                    <td width="64%" >: <?php print_r(env('DISPONIBILIDAD'));?></td>
                </tr>
                <tr>
                    <td width="1%"></td>
                    <td width="10%"></td>
                    <td width="25%" ><strong>TIEMPO DE ENTREGA</strong></td>
                    <td width="64%" >: <?php echo e(@$data_asignacion->tiempoEntrega); ?></td>
                </tr>
                <tr>
                    <td width="1%"></td>
                    <td width="10%"></td>
                    <td width="25%" ><strong>OFERTA VÁLIDA</strong></td>
                    <td width="64%" >: <?php echo e(@$data_asignacion->ofertaValida); ?></td>
                </tr>
            </table>

            <table width="100%">
            <?php for($i = 1; $i <=4; $i++): ?>
                <tr>
                    <td width="100%" align="center"><strong style="font-size: 12px;color:white"></strong></td>
                </tr>
            <?php endfor; ?>
            </table>

            <table class="tabla2" width="100%">
                <tr>
                    <td width="1%" align="right"></td>
                    <td width="10%" align="center"><strong>V</strong></td>
                    <td width="89%" colspan="2" ><strong>CUENTAS PARA DEPÓSITOS BANCARIOS</strong></td>
                </tr>
            </table>

            <table class="tabla2" width="100%">
                <tr>
                    <td width="1%"></td>
                    <td width="10%"></td>
                    <td width="50%" ><strong>CUENTA CORRIENTE SOLES BCP LIMA </strong></td>
                    <td width="39%" >: <?php print_r(env('CUENTA_CORRIENTE_SOLES_BCP_LIMA'));?></td>
                </tr>
                <tr>
                    <td width="1%"></td>
                    <td width="10%"></td>
                    <td width="50%" ><strong>CUENTA INTERBANCARIA SOLES BCP LIMA  </strong></td>
                    <td width="39%" >: <?php print_r(env('CUENTA_INTERBANCARIA_SOLES_BCP_LIMA'));?></td>
                </tr>

                <tr>
                    <td width="1%"></td>
                    <td width="10%"></td>
                    <td width="50%" ><strong>CUENTA CORRIENTE SOLES INTERBANK LIMA</strong></td>
                    <td width="39%" >: <?php print_r(env('CUENTA_CORRIENTE_SOLES_INTERBANK_LIMA'));?></td>
                </tr>

                <tr>
                    <td width="1%"></td>
                    <td width="10%"></td>
                    <td width="50%" ><strong>CUENTA INTERBANCARIA SOLES INTERBANK LIMA</strong></td>
                    <td width="39%" >: <?php print_r(env('CUENTA_INTERBANCARIA_SOLES_INTERBANK_LIMA'));?></td>
                </tr>

                <tr>
                    <td width="1%"></td>
                    <td width="10%"></td>
                    <td width="50%" ><strong>CUENTA CORRIENTE DE DETRACCIÓN NACIÓN</strong></td>
                    <td width="39%" >: <?php print_r(env('CUENTA_CORRIENTE_DETRACCION_NACION'));?></td>
                </tr>

            </table>
            <table class="tabla2" width="100%">
                <tr>
                   
                    <td width="100%" align="center"><strong>Atentamente.</strong></td>
                </tr>
            </table>
        </main>
    </body>
</html><?php /**PATH C:\Users\user\Desktop\Proyecto_Apiqimi\Apiqimi\resources\views/TareasAdmi/DetalleTareas.blade.php ENDPATH**/ ?>