<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
	<style>
	.container {
		width:996px;
		margin:0px auto;
		font-size:12px;
	}
	section{
		padding: 10px;
		background:white;
		-moz-border-radius:5px;-webkit-border-radius:5px;-o-border-radius:5px;border-radius:5px;
	}
	section {
		float: left;
		width: 50%;
	}
	
	/* para 980px o menos */
	@media  screen and (max-width:980px) {
		.container {
			width:98%;
		}
		section {
			width:68%;
		}
	}
 
	/* para 700px o menos */
	@media  screen and (max-width:700px) {
		section {
			float:none;
			width:96%;
		}
		section {
			font-size:10px;
		}
		
	}
 
	/* para 480px o menos */
	@media  screen and (max-width:480px) {
		
		section {
			font-size:10px;
		}
		section {
			width:94%;
		}
	}
    .image {
           position: relative;
           
           width: 100%;
           height: 140px;
           color: white;
           background: url('https://api.kirasportswear.com/storage/app/banner-curvo.png') no-repeat;
           background-size: 700px 140px;
		   
       }
       .image1 {
           position: relative;
           width: 100%;
           height: 20px;
           
           color: black;
           background: url('https://api.kirasportswear.com/storage/app/LINEA_DEGRADADA.png') no-repeat;
           background-position: 0 9px !important;
           background-size: 700px 20px;
		   
       }
       .image2 {
           position: relative;
           width: 100%;
           height: 120px;
           color: white;
           background: url('https://api.kirasportswear.com/storage/app/banner-invertido.png') no-repeat;
           background-size: 700px 120px;
		   
       }
       
	</style>
 
</head>
 
<body>
 
<div class="container">
	

	<section>
	    <?php 
        $texto="";
        $estilo1='style="color:#808b96;"';
        $estilo2='style="color:#808b96;"';
        $estilo2_gracias='';
        $estilo4='style="color:#808b96;"';
        $estilo5='style="color:#808b96;"';

        $estilo_imagen1='style="opacity: 0.5;"';
        $estilo_imagen2='style="opacity: 0.5;"';
        $estilo_imagen4='style="opacity: 0.5;"';
        $estilo_imagen5='style="opacity: 0.5;"';
        switch ($pedido->EstadoPedido) {
          case 1:
            $texto="Pedido realizado esperando confirmacion de pago";
            $estilo1='style="color:#A83EDD;"';
            $titulo="Pedido Realizado";
            $estilo_imagen1='style="opacity: 1;"';
            # code...
            break;
          case 2:
            $texto="La confirmacion del pago de tu pedido fue aprobado";
            $estilo2='style="color:#A83EDD;"';
            $titulo= "Pedido Aprobado";
            $estilo2_gracias='!Muchas Gracias!';
            $estilo_imagen2='style="opacity: 1;"';
            # code...
            break;
          case 3:
            $estilo2_gracias='!Lo sentimos! Hemos tenido que anular tu pedido';
            $titulo = "Pedido anulado";
            $texto="Uno de nuestros colaboradores se comunicará contigo para explicarte el motivo";
            break;
          case 4:
            $texto="¡Falta poco para que recibas tu compra!";
            $estilo4='style="color:#A83EDD;"';
            $titulo = "Pedido en Transito";
            $estilo_imagen4='style="opacity: 1;"';
            # code...
            break;
          case 5:
            $texto="¡Felidades su pedido ya llego a casa!";
            $estilo5='style="color:#A83EDD;"';
            $titulo="Pedido Entregado";
            $estilo_imagen5='style="opacity: 1;"';
            # code...
            break;
        }
        ?>

    <table width="100%" class="image"> 
        <tr>
          <td width="25%"  align="right"></td>
          <td width="25%"  align="left" colspan="2" style=""></td>
          <td width="50%"  align="center" ><strong style="font-size: large;color:white"><?php echo e($titulo); ?></strong></td>
         
        </tr>
        <tr>
          <td width="25%"  align="right"></td>
          <td width="25%"  align="left" colspan="2" ><img id="logo" src="https://api.kirasportswear.com/storage/app/logo_kira.png" alt="" width="85" height="45"></td>
          <td width="50%"  align="right" ></td>
          
        </tr>
        
    </table>
    <table width="100%" >
        <?php for($i = 1; $i <=10; $i++): ?>
        <tr>
          <td width="100%"  align="right"></td>
        </tr>
        <?php endfor; ?>
    </table>
    <table width="100%" >
        <tr>
          <td width="20%"  align="left"></td>
          <td width="60%"  align="center"><strong style="font-size: medium;"><?php echo e($estilo2_gracias); ?></strong></td>
          <td width="20%"  align="left"></td>
        </tr>
    </table>

    <table width="100%" >
        
        <tr>
          <td width="20%"  align="left"></td>
          <td width="60%"  align="center"><strong style="font-size: medium;color:#808b96;"><?php echo e($texto); ?></strong></td>
          <td width="20%"  align="left"></td>
        </tr>
    </table>
    <table width="100%" >
        <tr>
          <td width="20%"  align="left"></td>
          <td width="60%"  align="center"><strong style="font-size: medium;color:#808b96;">Número de pedido :</strong></td>
          <td width="20%"  align="left"></td>
        </tr>
    </table>
    <table width="100%" >
        <tr>
          <td width="20%"  align="left"></td>
          <td width="60%"  align="center"><strong style="font-size: medium;color:#808b96;"><?php echo e($pedido->id); ?></strong></td>
          <td width="20%"  align="left"></td>
        </tr>
    </table>
    <?php if($pedido->EstadoPedido==1 || $pedido->EstadoPedido==2 || $pedido->EstadoPedido==4 || $pedido->EstadoPedido==5): ?>
    <table width="100%" >
        <?php for($i = 1; $i <=10; $i++): ?>
        <tr>
          <td width="100%"  align="right"></td>
        </tr>
        <?php endfor; ?>
    </table>
    <table width="100%" class="image1" cellspacing="0">
        <tr>
          <td width="20%"  align="left"></td>
          <td width="15%"  align="left" style="padding: 0;" >
          <img id="logo" <?php echo($estilo_imagen1);?> src="https://api.kirasportswear.com/storage/app/CIRCULO.png" alt="" width="40" height="40">
          
          </td>
          <td width="15%"  align="left" style="padding: 0;">
          <img id="logo" <?php echo($estilo_imagen2);?> src="https://api.kirasportswear.com/storage/app/CIRCULO.png" alt="" width="40" height="40">
          </td>
          <td width="15%"  align="left" style="padding: 0;">
          <img id="logo" <?php echo($estilo_imagen4);?> src="https://api.kirasportswear.com/storage/app/CIRCULO.png" alt="" width="40" height="40">
          </label>
          </td>
          <td width="15%"  align="left" style="padding: 0;">
          <img id="logo" <?php echo($estilo_imagen5);?> src="https://api.kirasportswear.com/storage/app/CIRCULO.png" alt="" width="40" height="40">
          </td>
          <td width="20%"  align="left"></td>
        </tr>
        
        <tr>
          <td width="20%"  align="left"></td>
          <td width="15%"  align="center">&nbsp;</td>
          <td width="15%"  align="center">&nbsp;</td>
          <td width="15%"  align="center">&nbsp;</td>
          <td width="15%"  align="center">&nbsp;</td>
          <td width="20%"  align="left"></td>
        </tr>
        <tr>
          <td width="20%"  align="left"></td>
          <td width="15%"  align="left"><strong <?php echo($estilo1); ?>>PEDIDO REALIZADO</strong></td>
          <td width="15%"  align="left"><strong <?php echo($estilo2); ?>>PAGO<br> APROBADO</strong></td>
          <td width="15%"  align="left"><strong <?php echo($estilo4); ?>>PEDIDO EN TRANSITO</strong></td>
          <td width="15%"  align="left"><strong <?php echo($estilo5); ?>>PEDIDO ENTREGADO</strong></td>
          <td width="20%"  align="left"></td>
        </tr>
    </table>
    <table width="100%" >
        <?php for($i = 1; $i <=10; $i++): ?>
        <tr>
          <td width="100%"  align="right"></td>
        </tr>
        <?php endfor; ?>
    </table>
    <table width="100%" >
        <tr>
          <td width="20%"  align="left"></td>
          <td width="60%"  align="left"><strong style="font-size: small; color:#808b96">Direccion de envio : </strong><strong style="font-size: small;color:#808b96"><?php echo e(@$pedido->direccionEnvio); ?></td>
          <td width="20%"  align="left"></td>
        </tr>
    </table>
    <?php
    $tipo_pago="";
    $total=number_format($pedido->precioTotal, 2, '.', '');
    switch ($pedido->TipoPago) {
      case 1:
        # code...
        $tipo_pago="Transferencia bancaria (S/".$total.")";
        break;
      case 2:
        $tipo_pago="Efectivo Móvil S/".$total.")";
        # code...
        break;
      case 3:
        # code...
        $tipo_pago="Tarjeta Débito (S/".$total.")";
        break;
    } 
    ?>
    <table width="100%" >
        <tr>
          <td width="20%"  align="left"></td>
          <td width="60%"  align="left"><strong style="font-size: small; color:#808b96">Forma de pago : </strong><strong style="font-size: small;color:#808b96"><?php echo e($tipo_pago); ?></strong></td>
          <td width="20%"  align="left"></td>
        </tr>
    </table>
    
    <table width="100%" >
        <?php for($i = 1; $i <=20; $i++): ?>
        <tr>
          <td width="100%"  align="right"></td>
        </tr>
        <?php endfor; ?>
    </table>
   
    </table>
	<table width="100%" >
        <tr>
          <td width="100%"  align="center" style="color:#808b96;"> Para consultar sobre compras realizadas en kirasportwear.com contactenos por el chat</td>
        </tr>
        <tr>
          <td width="100%"  align="center" style="color:#808b96;"> online del sitio oficial de kira de Lun. a Vie. de 9 a.m a 6 p.m y Sab 9 a.m a 1 p.m</td>
        </tr>
        <tr>
          <td width="100%"  align="center" style="color:#808b96;"> o escribenos por correo a atencionalcliente@kirasporswear.com</td>
        </tr>
    </table>
    <table width="100%">
		<tr>
		  <td width="20%" align="center"></td>
		  <td width="60%" align="center" style="color:#808b96;"><h2>Resumen del pedido<h2></td>
		  <td width="20%" align="center"></td>
		</tr>
		
	</table>
	<table width="100%">
		<tr>
		  <td width="50%" align="right" style="color:#808b96;"><h3>Productos<h3></td>
		  <td width="50%" align="center"></td>
		</tr>
		
		 
	</table>
	<table width="100%">
	    <?php $__currentLoopData = $detallePedido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
		  <td width="50%" HEIGHT="1%" align="right" rowspan="5"><img id="logo" src="<?php echo e(@$detalle->imagen); ?>" alt="" width="100" height="100"></td>
		  <td width="50%" HEIGHT="1%" align="left" ><strong style="font-size: medium;"><?php echo e(@$detalle->nombre); ?></strong></td>
		</tr>
		<tr>
		  <td width="100%"HEIGHT="1%" align="left" ><strong style="color: #808B96;">Talla: <?php echo e(@$detalle->nombreTalla); ?></strong></td>
		</tr>
    <?php
      $precio_detalle=number_format(@$detalle->precio, 2, '.', ''); 
    ?>
  
		<tr>
		  <td width="100%" HEIGHT="1%" align="left" ><strong>S/.<?php echo e(@$precio_detalle); ?> </strong></td>
		</tr>
		<tr>
		  <td width="100%" HEIGHT="1%" align="left" ><strong>Cantidad</strong></td>
		</tr>
		<tr>
		  <td width="100%" HEIGHT="1%" align="left" ><input type="number"disabled="disabled" style="width:35px;" value="<?php echo e(@$detalle->cantidad); ?>"></td>
		</tr>
		<tr>
		  <td align="left" ></td>
		</tr>
	   	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
  <table width="100%" >
        <?php for($i = 1; $i <=15; $i++): ?>
        <tr>
          <td width="100%"  align="right"></td>
        </tr>
        <?php endfor; ?>
  </table>
	<?php @$subtotal=number_format(@$pedido->precioTotal-@$pedido->costoEnvio, 2, '.', '');?>
	<table width="100%"  cellpadding="12">
		<tr>
		  <td width="25%" HEIGHT="1%"align="left"><strong><strong></td>
		  <td width="25%" HEIGHT="1%"align="center" style="border-bottom-style:solid;border-bottom-color: #D85EDC;border-bottom-width: 5px;  border-right-style: solid;border-right-color: #D85EDC;border-right-width: 5px;"><strong style="font-size: medium; color:#000000;">Subtotal:<strong></td>
		  <td width="25%" HEIGHT="1%"align="left" style="border-bottom-style:solid; border-bottom-color: #D85EDC;border-bottom-width: 5px;" ><strong style="font-size: medium; color:#000000;">S/.<?php echo e(@$subtotal); ?><strong></td>
		  <td width="25%" HEIGHT="1%"align="left"><strong><strong></td>
		</tr>
		</tr>
    <?php @$costo_envio=number_format(@$pedido->costoEnvio, 2, '.', '');?>
		<tr>
		  <td width="25%" HEIGHT="1%"align="left"><strong><strong></td>
		  <td width="25%" HEIGHT="1%"align="center" style="border-bottom-style:solid;border-bottom-color: #D85EDC;border-bottom-width: 5px;  border-right-style: solid;border-right-color: #D85EDC;border-right-width: 5px;"><strong style="font-size: medium; color:#000000;">Flete:<strong></td>
		  <td width="25%" HEIGHT="1%"align="left" style="border-bottom-style:solid; border-bottom-color: #D85EDC;border-bottom-width: 5px;" ><strong style="font-size: medium; color:#000000;">S/.<?php echo e(@$costo_envio); ?><strong></td>
		  <td width="25%" HEIGHT="1%"align="left"><strong><strong></td>
		</tr>
		
		
	</table>
  <?php @$costo_final=number_format(@$pedido->precioTotal, 2, '.', '');?>
	<table width="100%">
		<tr>
		  <td width="25%" HEIGHT="1%"align="left"><strong><strong></td>
		  <td width="50%" HEIGHT="1%"align="right" colspan="2" style="background-color: #D85EDC;"><strong style="color:white;font-size: medium; text-align:center;">Total: S/.<?php echo e(@$costo_final); ?><strong></td>
		  <td width="25%" HEIGHT="1%"align="left"><strong><strong></td>
		</tr>
	</table>
  <?php endif; ?>
  <table width="100%" >
        <?php for($i = 1; $i <=15; $i++): ?>
        <tr>
          <td width="100%"  align="right"></td>
        </tr>
        <?php endfor; ?>
  </table>
	<table width="100%">
		<tr>
		  
		  <td width="100%" align="center" style="color:#808080;">¿Quieres mantenerme al tanto de las promociones y las novedades de Kira?</td>
		  
		</tr>
		<tr>
		  <td width="100%" align="center" style="color:#808080;">Siguenos en nuestras redes sociales</td> 
		</tr>
	</table>
	<table width="100%">
		<tr>
		  <td width="20%" align="center"></td>
		  <td width="20%" align="center"></td>
		  <td width="10%" align="center"><a href="https://www.instagram.com/kiraperu.oficial/"><img id="logo" src="https://api.kirasportswear.com/storage/app/instagram.png" alt="" width="40" height="40"></a></td>
          <td width="10%" align="center"><a href="https://www.facebook.com/kiraperu.oficial"><img id="logo" src="https://api.kirasportswear.com/storage/app/facebook.png" alt="" width="40" height="40"></a></td>
		  <td width="20%" align="center"></td>
		  <td width="20%" align="center"></td>
		</tr>
	</table>

    <table width="100%" class="image2">
		<tr>
		  <td width="5" align="center"></td>
        </tr>
        <tr>
          <td width="5" HEIGHT="1" align="center" style="font-size:9px;">@Copyright  2020.KIRA SPORTSWEAR</td>
        </tr>
		<tr>
		  <td width="5" HEIGHT="1" align="center" style="font-size:9px;">Todos los precios y condiciones de este sitio son validos solo </td>
        </tr>
        <tr>
		  <td width="5"  HEIGHT="1" align="center" style="font-size:9px;">para compras en kirasportswear.com</td>
        </tr>
		<tr>
		  <td width="5" HEIGHT="1" align="center" style="font-size:9px;">Las imagenes de los productos son referenciales y pueden variar sin previo aviso.</td>
        </tr>
		
    </table>
	</section>

</div>
</body>
</html><?php /**PATH C:\Users\user\Desktop\TiendaAdministrable\kirasport_sin-facturacion\KiraSportTalla\TiendaAdministrable\resources\views/pedidos/ficha_seguimiento.blade.php ENDPATH**/ ?>