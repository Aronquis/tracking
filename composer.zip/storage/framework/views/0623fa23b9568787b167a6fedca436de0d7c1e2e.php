<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
	<style>
	.container {
		width:996px;
		margin:0px auto;
		font-size:12px;
	}
	section{
		padding: 10px;
		background:white;
		-moz-border-radius:5px;-webkit-border-radius:5px;-o-border-radius:5px;border-radius:5px;
	}
	section {
		float: left;
		width: 45%;
	}
	
	/* para 980px o menos */
	@media  screen and (max-width:980px) {
		.container {
			width:98%;
		}
		section {
			width:68%;
		}
	}
 
	/* para 700px o menos */
	@media  screen and (max-width:700px) {
		section {
			float:none;
			width:96%;
		}
		section {
			font-size:10px;
		}
		
	}
 
	/* para 480px o menos */
	@media  screen and (max-width:480px) {
		
		section {
			font-size:10px;
		}
		section {
			width:94%;
		}
	}
    .image {
           position: relative;
           width: 500px;
           height: 200px;
           display: table-cell;
           color: white;
           background: url('https://educamp.josejollja.com/assets/header.c79ef46d.png');
           background-size: contain;
           background-repeat: no-repeat;
		   
       }
       .image2 {
           position: relative;
           width: 500px;
           height: 200px;
           display: table-cell;
           color: white;
           background: url('https://educamp.josejollja.com/assets/footer.b2d03a35.png');
           background-size: contain;
           background-repeat: no-repeat;
		   
       }
       p {
        text-align: justify;
        text-justify: inter-word;
        }
	</style>
 
</head>
 
<body>
 
<div class="container">
	

	<section>
    <table width="45%" class="image"> 
        
        
    </table>
    
	<table width="100%">
		<tr>
		  
		  <td width="100%" align="left" ><h2>Hola <?php echo e($registro->nombres); ?>!</h2></td>
		  
		</tr>
		<tr>
		  <td width="100%" align="center" style="color:#2F3030;font-size:15px;"><p>Gracias por inscribirte al <strong style="color: #2C3E50;">EduCamp 2021: habilidades para el futuro de la Educación</strong>, ha realizarse del 12 al 14 de julio.</p></td> 
		</tr>
        <tr>
		  <td width="100%" align="center" style="color:#2F3030;font-size:15px;">
          <p>
          Días previos al evento recibirás el acceso a la plataforma virtual del <span style="color: #2874A6;"><a href="http://www.ce2avirtual.org/">Centro de Excelencia en Enseñanza y Aprendizaje</a></span>  (CE2A). En esta plataforma encontrarás la información para acceder a las charlas principales, mesas de discusión, talleres y webinars.
          </p>
		  </td> 
        </tr>
        <tr>
		  <td width="100%" align="center" style="color:#2F3030;font-size:15px;">
          <p>Te animamos a compartir con tus colegas el evento para que más personas puedan aprovechar de la propuesta innovadora del evento.</p>
		  </td> 
        </tr>
	</table>
	<table width="100%">
		</tr>
          <td width="100%" align="left" style="color:#2F3030;font-size:15px;">
          <p>
          Atentamente,
          </p>
		  </td>
		</tr> 
        <tr>
          <td width="100%" align="left" style="color:#2F3030;font-size:15px;">
          <span>
          Comite Organizador
		  </span>
		  </td> 
        </tr>
		<tr>
          <td width="100%" align="left" style="color:#2F3030;font-size:15px;">
          <p><strong>
          EduCamp 2021
          </strong>
		  </p>
		  </td> 
        </tr>
	</table>
    <table width="45%" class="image2">
		
		
    </table>
	</section>

</div>
</body>
</html><?php /**PATH /home/gnhikgzm/apiutec.softaki.com/resources/views/correo/correoRegistro.blade.php ENDPATH**/ ?>