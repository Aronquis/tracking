<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
 
	<style>
	
    .zona_impresion{
        width: 390px;
        padding:10px 5px 10px 5px;
        font-family: Arial, Helvetica, sans-serif;
        float:left;
        margin-left:00px;
        border-style: solid;
        border:1px solid  #999;
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.4); 

    }
	</style>
 
</head>
<body >
<div class="zona_impresion">
<br>
<table border="0" align="center" width="390px" >
<tr>
        <td align="center">          
            <img style="width: 200px; height: auto; opacity: 0.7;" src="<?php echo e(@$empresa->logo); ?>">
        </td>
        <td>&nbsp;</td>
    </tr>
    <tr>
        <td  align="center">
        .::<strong style="font-size:12px;color: #333;"> <?php echo e(strtoupper(@$empresa->nomEmpresa)); ?>::.<br>
        <?php echo e(strtoupper(@$empresa->direccion)); ?> <?php echo e(strtoupper(@$empresa->departamento)); ?> - <?php echo e(strtoupper(@$empresa->provincia)); ?> - <?php echo e(strtoupper(@$empresa->distrito)); ?><br>
        <strong>R.U.C: <?php echo e(strtoupper(@$empresa->ruc)); ?></strong><br>
        <strong>TICKET ELECTRÓNICO</strong><br>
        <strong><?php echo e($pedido->id); ?></strong><br>
       </td>
    </tr>
    <tr>
      <td align="center"></td>
    </tr>
    <tr>
        <td align="left"><strong style="font-size:12px;color: #333;">FECHA EMISIÓN:<strong><strong style="font-size:12px;color: #666;"><?php echo e($pedido->created_at); ?></strong></td>
    </tr>
    
    <tr>
        <?php switch($user->typeDocument):
            case (1): ?>:
                <td><strong style="font-size:12px;color: #333;">ADQUIRIENTE</strong><br><strong style="font-size:12px;color: #333;">NOMBRES:</strong><strong style="font-size:12px;color: #666;"><?php echo e(strtoupper(@$user->name)); ?>&nbsp;<?php echo e(strtoupper(@$user->surnames)); ?><strong><br><strong style="font-size:12px;color: #666;"><strong style="font-size:12px;color: #333;">DNI:</strong><?php echo e(strtoupper(@$user->numberDocument)); ?></strong>
                </td>
            <?php break; ?>
            <?php case (2): ?>:
                <td><strong style="font-size:12px;color: #333;">ADQUIRIENTE</strong><br><strong style="font-size:12px;color: #333;">NOMBRES:</strong><strong style="font-size:12px;color: #666;"><?php echo e(strtoupper(@$user->name)); ?>&nbsp;<?php echo e(strtoupper(@$user->surnames)); ?><strong><br><strong style="font-size:12px;color: #666;"><strong style="font-size:12px;color: #333;">CARNET ESTRANJERIA:</strong><?php echo e(strtoupper(@$user->numberDocument)); ?></strong>
                </td>
            <?php break; ?>
            <?php case (3): ?>:
                <td><strong style="font-size:12px;color: #333;">ADQUIRIENTE</strong><br><strong style="font-size:12px;color: #333;">NOMBRES:</strong><strong style="font-size:12px;color: #666;"><?php echo e(strtoupper(@$user->name)); ?>&nbsp;<?php echo e(strtoupper(@$user->surnames)); ?><strong><br><strong style="font-size:12px;color: #666;"><strong style="font-size:12px;color: #333;">PASAPORTE:</strong><?php echo e(strtoupper(@$user->numberDocument)); ?></strong>
                </td>
            <?php break; ?>
        <?php endswitch; ?>
        
    </tr>
    <tr>
        <td><strong style="font-size:12px;color: #333;">CORREO:</strong><strong style="font-size:12px;color: #666;"><?php echo e(strtoupper(@$user->email)); ?></strong></td>
    </tr>
    <tr>
        <td><b><strong style="font-size:12px;color: #333;">MONEDA:</strong></b><strong style="font-size:12px;color: #666;"> PEN</strong></td>
    </tr>
    
</table>

<table border="0" align="center" width="300px">
    <tr>
        <td><strong style="font-size:12px;color: #333;">[CANT.]</strong></td>
        <td><strong style="font-size:12px;color: #333;">DESCRIPCIÓN</strong></td>
        <td align="right"><strong style="font-size:12px;color: #333;">P/U</strong></td>
        <td align="right"><strong style="font-size:12px;color: #333;">TOTAL</strong></td>
    </tr>
    <tr>
      <td colspan="4">------------------------------------------------------------------------</td>
    </tr>
    <?php $__currentLoopData = $detallePedido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><strong style="font-size:12px;color: #333;">[<?php echo e($detalle->cantidad); ?>]</strong></td>
        <td style="font-size:12px;color: #333;"><?php echo e($detalle->nombre); ?></td>
        <td align='right' style="font-size:12px;color: #333;"><?php echo e(number_format($detalle->precio, 2, '.', '')); ?></td>
        <td align='right' style="font-size:12px;color: #333;"><?php echo e(number_format($detalle->total, 2, '.', '')); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
    <tr>
      <td colspan="4">------------------------------------------------------------------------</td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td align="right"><strong style="font-size:12px;">GRAV &nbsp;</strong></td>
        <td align="right" style="font-size:12px;"><?php echo e(number_format($pedido->precioTotal-$pedido->precioTotal*0.18, 2, '.', '')); ?></td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td align="right"><strong style="font-size:12px;">IGV (18%) &nbsp;</strong></td>
        <td align="right" style="font-size:12px;"><?php echo e(number_format($pedido->precioTotal*0.18, 2, '.', '')); ?></td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td align="right"><strong style="font-size:12px;">EXON &nbsp;</strong></td>
        <td align="right" style="font-size:12px;">0.00</td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td align="right"><strong style="font-size:12px;">ICBPER &nbsp;</strong></td>
        <td align="right" style="font-size:12px;">0.00</td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td align="right"><strong style="font-size:12px;">TOTAL &nbsp;</strong></td>
        <td align="right" style="font-size:12px;"><?php echo e(number_format($pedido->precioTotal, 2, '.', '')); ?></td>
    </tr>
    <tr>
      <td colspan="4">------------------------------------------------------------------------</td>
    </tr>
    <tr>
        <td colspan="4" height="10" align="center" style="font-size:12px;"><strong >SON:</strong> <?php $decimales = explode(".",number_format($pedido->precioTotal,2)); $entera=explode(".",$pedido->precioTotal); echo(convertir($entera[0]).' CON '. $decimales[1].'/100 '.'SOLES');?></td>    
    </tr>
    <tr>
      <td colspan="4">------------------------------------------------------------------------</td>
    </tr>
    <tr>
    <td colspan="4" align="center" style="font-size:12px;"><small>Representación impresa de su comprobante. <br>Verifica la validez de este documento en: <br><strong>https://kirasportswear.com</strong><br>
    
    <br>
    </tr>
    <tr>
        <td colspan="4" align="center"><img src="https://chart.googleapis.com/chart?chs=100x100&cht=qr&chl=http%3A%2F%2Fwww.google.com%2F&choe=UTF-8" title="https://kirasportswear.com
" /></td>
    </tr>
    <?php
    $tipo_pago="";
    $total=number_format($pedido->precioTotal, 2, '.', '');
    switch ($pedido->TipoPago) {
      case 1:
        # code...
        $tipo_pago="TRANS.BANCARIA";
        break;
      case 2:
        $tipo_pago="EFEC.MOVIL";
        # code...
        break;
      case 3:
        # code...
        $tipo_pago="DÉBITO";
        break;
    } 
    ?>
    <tr>
      <td colspan="4" align="center" style="font-size:12px;"><strong>Medios de pago <br></strong>
      <br ><strong><?php echo e($tipo_pago); ?>:</strong> <?php echo e($total); ?>

      <br><strong>Vuelto:</strong> 0.00
      </td>
    </tr>
    <tr>
      <td colspan="4">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="4" align="center" style="font-size:12px;">
        ¡Gracias por su compra!
        <br><br><small>Emitido desde<br><strong>https://kirasportswear.com</strong></small>
        </td>
    </tr>
</table>

<?php
function unidad($numuero){
    $numu="";
    switch ($numuero)
    {
    case 9:
    {
    $numu = "NUEVE";
    break;
    }
    case 8:
    {
    $numu = "OCHO";
    break;
    }
    case 7:
    {
    $numu = "SIETE";
    break;
    } 
    case 6:
    {
    $numu = "SEIS";
    break;
    } 
    case 5:
    {
    $numu = "CINCO";
    break;
    } 
    case 4:
    {
    $numu = "CUATRO";
    break;
    } 
    case 3:
    {
    $numu = "TRES";
    break;
    } 
    case 2:
    {
    $numu = "DOS";
    break;
    } 
    case 1:
    {
    $numu = "UN";
    break;
    } 
    case 0:
    {
    $numu = "";
    break;
    } 
    }
    return $numu; 
    }
    
    function decena($numdero){
    
    if ($numdero >= 90 && $numdero <= 99)
    {
    $numd = "NOVENTA ";
    if ($numdero > 90)
    $numd = $numd."Y ".(unidad($numdero - 90));
    }
    else if ($numdero >= 80 && $numdero <= 89)
    {
    $numd = "OCHENTA ";
    if ($numdero > 80)
    $numd = $numd."Y ".(unidad($numdero - 80));
    }
    else if ($numdero >= 70 && $numdero <= 79)
    {
    $numd = "SETENTA ";
    if ($numdero > 70)
    $numd = $numd."Y ".(unidad($numdero - 70));
    }
    else if ($numdero >= 60 && $numdero <= 69)
    {
    $numd = "SESENTA ";
    if ($numdero > 60)
    $numd = $numd."Y ".(unidad($numdero - 60));
    }
    else if ($numdero >= 50 && $numdero <= 59)
    {
    $numd = "CINCUENTA ";
    if ($numdero > 50)
    $numd = $numd."Y ".(unidad($numdero - 50));
    }
    else if ($numdero >= 40 && $numdero <= 49)
    {
    $numd = "CUARENTA ";
    if ($numdero > 40)
    $numd = $numd."Y ".(unidad($numdero - 40));
    }
    else if ($numdero >= 30 && $numdero <= 39)
    {
    $numd = "TREINTA ";
    if ($numdero > 30)
    $numd = $numd."Y ".(unidad($numdero - 30));
    }
    else if ($numdero >= 20 && $numdero <= 29)
    {
    if ($numdero == 20)
    $numd = "VEINTE ";
    else
    $numd = "VEINTI".(unidad($numdero - 20));
    }
    else if ($numdero >= 10 && $numdero <= 19)
    {
    switch ($numdero){
    case 10:
    {
    $numd = "DIEZ ";
    break;
    }
    case 11:
    { 
    $numd = "ONCE ";
    break;
    }
    case 12:
    {
    $numd = "DOCE ";
    break;
    }
    case 13:
    {
    $numd = "TRECE ";
    break;
    }
    case 14:
    {
    $numd = "CATORCE ";
    break;
    }
    case 15:
    {
    $numd = "QUINCE ";
    break;
    }
    case 16:
    {
    $numd = "DIECISEIS ";
    break;
    }
    case 17:
    {
    $numd = "DIECISIETE ";
    break;
    }
    case 18:
    {
    $numd = "DIECIOCHO ";
    break;
    }
    case 19:
    {
    $numd = "DIECINUEVE ";
    break;
    }
    } 
    }
    else
    $numd = unidad($numdero);
    return $numd;
    }
    
    function centena($numc){
    if ($numc >= 100)
    {
    if ($numc >= 900 && $numc <= 999)
    {
    $numce = "NOVECIENTOS ";
    if ($numc > 900)
    $numce = $numce.(decena($numc - 900));
    }
    else if ($numc >= 800 && $numc <= 899)
    {
    $numce = "OCHOCIENTOS ";
    if ($numc > 800)
    $numce = $numce.(decena($numc - 800));
    }
    else if ($numc >= 700 && $numc <= 799)
    {
    $numce = "SETECIENTOS ";
    if ($numc > 700)
    $numce = $numce.(decena($numc - 700));
    }
    else if ($numc >= 600 && $numc <= 699)
    {
    $numce = "SEISCIENTOS ";
    if ($numc > 600)
    $numce = $numce.(decena($numc - 600));
    }
    else if ($numc >= 500 && $numc <= 599)
    {
    $numce = "QUINIENTOS ";
    if ($numc > 500)
    $numce = $numce.(decena($numc - 500));
    }
    else if ($numc >= 400 && $numc <= 499)
    {
    $numce = "CUATROCIENTOS ";
    if ($numc > 400)
    $numce = $numce.(decena($numc - 400));
    }
    else if ($numc >= 300 && $numc <= 399)
    {
    $numce = "TRESCIENTOS ";
    if ($numc > 300)
    $numce = $numce.(decena($numc - 300));
    }
    else if ($numc >= 200 && $numc <= 299)
    {
    $numce = "DOSCIENTOS ";
    if ($numc > 200)
    $numce = $numce.(decena($numc - 200));
    }
    else if ($numc >= 100 && $numc <= 199)
    {
    if ($numc == 100)
    $numce = "CIEN ";
    else
    $numce = "CIENTO ".(decena($numc - 100));
    }
    }
    else
    $numce = decena($numc);
    
    return $numce; 
    }
    
    function miles($nummero){
    if ($nummero >= 1000 && $nummero < 2000){
    $numm = "MIL ".(centena($nummero%1000));
    }
    if ($nummero >= 2000 && $nummero <10000){
    $numm = unidad(Floor($nummero/1000))." MIL ".(centena($nummero%1000));
    }
    if ($nummero < 1000)
    $numm = centena($nummero);
    
    return $numm;
    }
    
    function decmiles($numdmero){
    if ($numdmero == 10000)
    $numde = "DIEZ MIL";
    if ($numdmero > 10000 && $numdmero <20000){
    $numde = decena(Floor($numdmero/1000))."MIL ".(centena($numdmero%1000)); 
    }
    if ($numdmero >= 20000 && $numdmero <100000){
    $numde = decena(Floor($numdmero/1000))." MIL ".(miles($numdmero%1000)); 
    } 
    if ($numdmero < 10000)
    $numde = miles($numdmero);
    
    return $numde;
    } 
    
    function cienmiles($numcmero){
    if ($numcmero == 100000)
    $num_letracm = "CIEN MIL";
    if ($numcmero >= 100000 && $numcmero <1000000){
    $num_letracm = centena(Floor($numcmero/1000))." MIL ".(centena($numcmero%1000)); 
    }
    if ($numcmero < 100000)
    $num_letracm = decmiles($numcmero);
    return $num_letracm;
    } 
    
    function millon($nummiero){
    if ($nummiero >= 1000000 && $nummiero <2000000){
    $num_letramm = "UN MILLON ".(cienmiles($nummiero%1000000));
    }
    if ($nummiero >= 2000000 && $nummiero <10000000){
    $num_letramm = unidad(Floor($nummiero/1000000))." MILLONES ".(cienmiles($nummiero%1000000));
    }
    if ($nummiero < 1000000)
    $num_letramm = cienmiles($nummiero);
    
    return $num_letramm;
    } 
    
    function decmillon($numerodm){
    if ($numerodm == 10000000)
    $num_letradmm = "DIEZ MILLONES";
    if ($numerodm > 10000000 && $numerodm <20000000){
    $num_letradmm = decena(Floor($numerodm/1000000))."MILLONES ".(cienmiles($numerodm%1000000)); 
    }
    if ($numerodm >= 20000000 && $numerodm <100000000){
    $num_letradmm = decena(Floor($numerodm/1000000))." MILLONES ".(millon($numerodm%1000000)); 
    }
    if ($numerodm < 10000000)
    $num_letradmm = millon($numerodm);
    
    return $num_letradmm;
    }
    
    function cienmillon($numcmeros){
    if ($numcmeros == 100000000)
    $num_letracms = "CIEN MILLONES";
    if ($numcmeros >= 100000000 && $numcmeros <1000000000){
    $num_letracms = centena(Floor($numcmeros/1000000))." MILLONES ".(millon($numcmeros%1000000)); 
    }
    if ($numcmeros < 100000000)
    $num_letracms = decmillon($numcmeros);
    return $num_letracms;
    } 
    
    function milmillon($nummierod){
    if ($nummierod >= 1000000000 && $nummierod <2000000000){
    $num_letrammd = "MIL ".(cienmillon($nummierod%1000000000));
    }
    if ($nummierod >= 2000000000 && $nummierod <10000000000){
    $num_letrammd = unidad(Floor($nummierod/1000000000))." MIL ".(cienmillon($nummierod%1000000000));
    }
    if ($nummierod < 1000000000)
    $num_letrammd = cienmillon($nummierod);
    
    return $num_letrammd;
    } 
    
    
    function convertir($numero){
    $numf = milmillon($numero);
    return $numf;
    }
?>
<div>
</body>
</html><?php /**PATH C:\Users\user\Desktop\TiendaAdministrable\kirasport_sin-facturacion\KiraSportTalla\TiendaAdministrable\resources\views/pedidos/ticket.blade.php ENDPATH**/ ?>